This lab asks students to complete a simple matrix multiplication, using only a single thread block, 
introducing them to the threading model.  It is appropriate to assign this lab any time after the material of Chapter 3 in 
the textbook is covered.  The two zipped files contain folders for the assignment and solution.  
Inside the assignment folder is a LAB1-README.txt file describing the assignment, which you can modify to fit the 
assignment needs, submission instructions, and grading information relevant to your offering, if necessary.