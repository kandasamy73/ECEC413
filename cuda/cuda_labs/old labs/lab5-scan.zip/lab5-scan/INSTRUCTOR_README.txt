This lab asks students to complete a data-parallel prefix sum (scan) 
reduction.  
It is appropriate to assign this lab any time after the material of 
Chapter 6 in the textbook is covered.  Note that the algorithmic material 
is not directly covered in the textbook: students should be referred to 
Mark Harris's "Parallel Prefix Sum (Scan) with CUDA", or instructed in 
the algorithms as part of the course materials.  

The two zipped files contain folders for the assignment and solution.  
Inside the assignment folder is a LAB5-README.txt file describing the 
assignment, which you can modify to fit the assignment needs, submission 
instructions, and grading information relevant to your offering, 
if necessary.  Note that the zipped files are much larger than those for 
other assignments, since reasonably large test files are included.   
