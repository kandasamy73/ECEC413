This lab asks students to complete a more generally applicable matrix 
multiplication implementation, using the full hierarchical threading 
model and the memory tiling optimizations.  It is appropriate to assign 
this lab any time after the material of Chapter 5 in the textbook is covered. 

The two zipped files contain folders for the assignment and solution.  
Inside the assignment folder is a LAB3-README.txt file describing the 
assignment, which you can modify to fit the assignment needs, submission 
instructions, and grading information relevant to your offering, 
if necessary.   
